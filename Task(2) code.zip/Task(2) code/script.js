// ======= Stopwatch logic =======
const display = document.getElementById('display');
const btnStart = document.getElementById('btn-start');
const btnLap   = document.getElementById('btn-lap');
const btnReset = document.getElementById('btn-reset');
const btnClearLaps = document.getElementById('btn-clear-laps');
const lapsBody = document.getElementById('laps-body');

// State
let startTime = 0;        // timestamp when started (performance.now)
let elapsedMs = 0;        // accumulated elapsed time while paused
let rafId = null;         // requestAnimationFrame id
let running = false;

let lastLapAt = 0;        // total elapsed when last lap was taken
let laps = [];            // { n, lapMs, totalMs }

// Format milliseconds to HH:MM:SS.CS (centiseconds)
function fmt(ms) {
  const cs = Math.floor((ms % 1000) / 10); // centiseconds
  const s  = Math.floor(ms / 1000) % 60;
  const m  = Math.floor(ms / 60000) % 60;
  const h  = Math.floor(ms / 3600000);
  const pad = (n, z=2) => String(n).padStart(z, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)}.${pad(cs)}`;
}

// Current total elapsed (ms)
function nowElapsed() {
  return running ? elapsedMs + (performance.now() - startTime) : elapsedMs;
}

// UI update loop
function tick() {
  display.textContent = fmt(nowElapsed());
  rafId = requestAnimationFrame(tick);
}

// Buttons state
function updateButtons() {
  const hasTime = nowElapsed() > 0;
  btnLap.disabled   = !running;
  btnReset.disabled = !hasTime;
  btnClearLaps.disabled = laps.length === 0;
  btnStart.textContent = running ? 'Pause' : (hasTime ? 'Resume' : 'Start');
}

// Start or pause
function toggle() {
  if (!running) {
    startTime = performance.now();
    running = true;
    tick();
  } else {
    // pause
    elapsedMs = nowElapsed();
    running = false;
    cancelAnimationFrame(rafId);
  }
  updateButtons();
}

// Reset stopwatch & laps
function reset() {
  running = false;
  cancelAnimationFrame(rafId);
  elapsedMs = 0;
  startTime = 0;
  lastLapAt = 0;
  display.textContent = fmt(0);
  laps = [];
  renderLaps();
  updateButtons();
}

// Add a lap
function addLap() {
  if (!running) return;
  const total = nowElapsed();
  const lapMs = total - lastLapAt;
  lastLapAt = total;
  laps.unshift({
    n: laps.length + 1,
    lapMs,
    totalMs: total
  });
  renderLaps();
  updateButtons();
}

// Remove a single lap by index (in rendered order)
function removeLap(idx) {
  laps.splice(idx, 1);
  renderLaps();
  updateButtons();
}

// Render laps table
function renderLaps() {
  if (laps.length === 0) {
    lapsBody.innerHTML = `
      <tr><td colspan="4" style="color:var(--muted); text-align:center; padding:14px;">
        No laps yet. Press <strong>Lap</strong> while running.
      </td></tr>`;
    return;
  }
  lapsBody.innerHTML = laps.map((lap, i) => `
    <tr>
      <td>${lap.n}</td>
      <td>${fmt(lap.lapMs)}</td>
      <td>${fmt(lap.totalMs)}</td>
      <td>
        <button class="link-btn" aria-label="Delete lap ${lap.n}" data-del="${i}">Delete</button>
      </td>
    </tr>
  `).join('');

  // wire delete buttons
  lapsBody.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const idx = Number(e.currentTarget.getAttribute('data-del'));
      removeLap(idx);
    });
  });
}

// Events
btnStart.addEventListener('click', toggle);
btnReset.addEventListener('click', reset);
btnLap.addEventListener('click', addLap);
btnClearLaps.addEventListener('click', () => { laps = []; renderLaps(); updateButtons(); });

// Keyboard shortcuts
window.addEventListener('keydown', (e) => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  if (e.code === 'Space') { e.preventDefault(); toggle(); }
  if (e.key.toLowerCase() === 'l') addLap();
  if (e.key.toLowerCase() === 'r') reset();
});

// Initialize
renderLaps();
updateButtons();
